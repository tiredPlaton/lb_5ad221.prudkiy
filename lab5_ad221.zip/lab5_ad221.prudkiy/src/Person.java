public class Person {
    private String surname;
    private String name;
    private int age;

    // Гетери
    public String getSurname() {
        return surname;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }

    // Сетери
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }

    // Метод printInfo
    public String printInfo() {
        return "Людина " + surname + " " + name + ", вік: " + age;
    }
}